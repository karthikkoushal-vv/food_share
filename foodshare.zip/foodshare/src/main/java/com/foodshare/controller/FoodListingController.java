package com.foodshare.controller;

import com.foodshare.dto.FoodListingRequest;
import com.foodshare.dto.FoodListingResponse;
import com.foodshare.service.FoodListingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/listings")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
@Tag(name = "Food Listings", description = "Endpoints for managing surplus food listings (GET, POST, PUT, DELETE)")
public class FoodListingController {

    private final FoodListingService foodListingService;

    @PostMapping
    @Operation(summary = "Create a surplus food listing (POST)", description = "Creates a new food listing with quantity, unit, and safe-to-eat-until time.")
    public ResponseEntity<FoodListingResponse> createListing(@Valid @RequestBody FoodListingRequest request) {
        FoodListingResponse response = foodListingService.createListing(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/available")
    @Operation(summary = "Get available food listings (GET)", description = "Retrieves all currently available food listings that have not expired.")
    public ResponseEntity<List<FoodListingResponse>> getAvailableListings() {
        return ResponseEntity.ok(foodListingService.getAvailableListings());
    }

    @GetMapping
    @Operation(summary = "Get all food listings (GET)", description = "Retrieves all food listings across all statuses.")
    public ResponseEntity<List<FoodListingResponse>> getAllListings() {
        return ResponseEntity.ok(foodListingService.getAllListings());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a food listing by ID (GET)", description = "Retrieves details of a specific food listing by its ID.")
    public ResponseEntity<FoodListingResponse> getListingById(@PathVariable Long id) {
        return ResponseEntity.ok(foodListingService.getListingById(id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a food listing (PUT)", description = "Updates details of an existing food listing.")
    public ResponseEntity<FoodListingResponse> updateListing(
            @PathVariable Long id,
            @Valid @RequestBody FoodListingRequest request
    ) {
        return ResponseEntity.ok(foodListingService.updateListing(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a food listing (DELETE)", description = "Deletes a food listing by its ID.")
    public ResponseEntity<Void> deleteListing(@PathVariable Long id) {
        foodListingService.deleteListing(id);
        return ResponseEntity.noContent().build();
    }
}
