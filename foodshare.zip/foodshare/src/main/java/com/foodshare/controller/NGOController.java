package com.foodshare.controller;

import com.foodshare.dto.NGORequest;
import com.foodshare.model.NGO;
import com.foodshare.service.NGOService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ngos")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
@Tag(name = "NGOs", description = "Endpoints for managing partner NGOs and Shelters (GET, POST, PUT, DELETE)")
public class NGOController {

    private final NGOService ngoService;

    @PostMapping
    @Operation(summary = "Register a new NGO (POST)", description = "Registers a new NGO, orphanage, or food shelter.")
    public ResponseEntity<NGO> createNGO(@Valid @RequestBody NGORequest request) {
        NGO ngo = ngoService.createNGO(request);
        return new ResponseEntity<>(ngo, HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all NGOs (GET)", description = "Retrieves all registered NGOs.")
    public ResponseEntity<List<NGO>> getAllNGOs() {
        return ResponseEntity.ok(ngoService.getAllNGOs());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get NGO by ID (GET)", description = "Retrieves an NGO by its ID.")
    public ResponseEntity<NGO> getNGOById(@PathVariable Long id) {
        return ResponseEntity.ok(ngoService.getNGOById(id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update NGO (PUT)", description = "Updates details of an existing NGO.")
    public ResponseEntity<NGO> updateNGO(@PathVariable Long id, @Valid @RequestBody NGORequest request) {
        return ResponseEntity.ok(ngoService.updateNGO(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete NGO (DELETE)", description = "Deletes an NGO by ID.")
    public ResponseEntity<Void> deleteNGO(@PathVariable Long id) {
        ngoService.deleteNGO(id);
        return ResponseEntity.noContent().build();
    }
}
