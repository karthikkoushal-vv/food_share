package com.foodshare.controller;

import com.foodshare.dto.DonorRequest;
import com.foodshare.model.Donor;
import com.foodshare.service.DonorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/donors")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
@Tag(name = "Donors", description = "Endpoints for managing food donors (GET, POST, PUT, DELETE)")
public class DonorController {

    private final DonorService donorService;

    @PostMapping
    @Operation(summary = "Register a new donor (POST)", description = "Registers a new donor (e.g., campus canteen, restaurant, hostel mess).")
    public ResponseEntity<Donor> createDonor(@Valid @RequestBody DonorRequest request) {
        Donor donor = donorService.createDonor(request);
        return new ResponseEntity<>(donor, HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all donors (GET)", description = "Retrieves a list of all registered donors.")
    public ResponseEntity<List<Donor>> getAllDonors() {
        return ResponseEntity.ok(donorService.getAllDonors());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get donor by ID (GET)", description = "Retrieves details of a specific donor by ID.")
    public ResponseEntity<Donor> getDonorById(@PathVariable Long id) {
        return ResponseEntity.ok(donorService.getDonorById(id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update donor (PUT)", description = "Updates details of an existing donor.")
    public ResponseEntity<Donor> updateDonor(@PathVariable Long id, @Valid @RequestBody DonorRequest request) {
        return ResponseEntity.ok(donorService.updateDonor(id, request));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete donor (DELETE)", description = "Deletes a donor by ID.")
    public ResponseEntity<Void> deleteDonor(@PathVariable Long id) {
        donorService.deleteDonor(id);
        return ResponseEntity.noContent().build();
    }
}
