package com.foodshare.controller;

import com.foodshare.dto.MonthlyReportResponse;
import com.foodshare.service.AnalyticsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/analytics")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
@Tag(name = "Analytics", description = "Endpoints for waste diversion and sustainability metrics (GET)")
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    @GetMapping("/monthly-diverted")
    @Operation(summary = "Get monthly waste diversion report (GET)", description = "View total food diverted from waste per month grouped by weight and units.")
    public ResponseEntity<MonthlyReportResponse> getMonthlyWasteDiversion(
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) Integer month
    ) {
        LocalDate now = LocalDate.now();
        int targetYear = (year != null) ? year : now.getYear();
        int targetMonth = (month != null) ? month : now.getMonthValue();

        MonthlyReportResponse report = analyticsService.getMonthlyWasteDiversion(targetYear, targetMonth);
        return ResponseEntity.ok(report);
    }
}
