package com.foodshare.controller;

import com.foodshare.dto.ClaimRequest;
import com.foodshare.dto.ClaimResponse;
import com.foodshare.service.ClaimService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/claims")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
@Tag(name = "Claims", description = "Endpoints for claiming food listings, marking collected, and canceling claims (GET, POST, PUT, DELETE)")
public class ClaimController {

    private final ClaimService claimService;

    @PostMapping
    @Operation(summary = "Claim an available food listing (POST)", description = "Allows an NGO to claim an active surplus food listing.")
    public ResponseEntity<ClaimResponse> claimListing(@Valid @RequestBody ClaimRequest request) {
        ClaimResponse response = claimService.claimListing(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PutMapping("/{id}/collect")
    @Operation(summary = "Mark claim collected (PUT)", description = "Marks a claimed food listing as picked up and collected.")
    public ResponseEntity<ClaimResponse> markCollected(@PathVariable Long id) {
        ClaimResponse response = claimService.markListingCollected(id);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    @Operation(summary = "Get all claims (GET)", description = "Retrieves a list of all claims across all statuses.")
    public ResponseEntity<List<ClaimResponse>> getAllClaims() {
        return ResponseEntity.ok(claimService.getAllClaims());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get claim by ID (GET)", description = "Retrieves details of a specific claim by ID.")
    public ResponseEntity<ClaimResponse> getClaimById(@PathVariable Long id) {
        return ResponseEntity.ok(claimService.getClaimById(id));
    }

    @GetMapping("/ngo/{ngoId}")
    @Operation(summary = "Get claims by NGO (GET)", description = "Retrieves all claims submitted by a specific NGO.")
    public ResponseEntity<List<ClaimResponse>> getClaimsByNgo(@PathVariable Long ngoId) {
        return ResponseEntity.ok(claimService.getClaimsByNgo(ngoId));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Cancel or delete a claim (DELETE)", description = "Cancels and deletes an active claim, releasing the listing back to available status.")
    public ResponseEntity<Void> deleteClaim(@PathVariable Long id) {
        claimService.deleteClaim(id);
        return ResponseEntity.noContent().build();
    }
}
