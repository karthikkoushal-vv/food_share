package com.foodshare.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI foodShareOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("FoodShare REST API")
                        .description("Surplus Food Donation Platform REST APIs with full CRUD (GET, POST, PUT, DELETE).\n\n" +
                                "### Available Endpoints:\n" +
                                "- **Listings API**: Create (`POST`), View (`GET`), Update (`PUT`), Delete (`DELETE`) surplus food listings.\n" +
                                "- **Donors API**: Create (`POST`), View (`GET`), Update (`PUT`), Delete (`DELETE`) food donors.\n" +
                                "- **NGOs API**: Create (`POST`), View (`GET`), Update (`PUT`), Delete (`DELETE`) partner NGOs.\n" +
                                "- **Claims API**: Claim food (`POST`), View claims (`GET`), Mark collected (`PUT`), Cancel/Delete (`DELETE`).\n" +
                                "- **Analytics API**: Monthly impact and waste diversion reports (`GET`).")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("FoodShare Support")
                                .email("support@foodshare.org")))
                .servers(List.of(
                        new Server().url("http://localhost:8080").description("Local Development Server")
                ));
    }
}
